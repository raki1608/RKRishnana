import java.util.*;//Importing the required java packages
class q6{//class name
	public static void main(String args[]){
		System.out.println("Enter the number");
		int a;
		Scanner s=new Scanner(System.in);
		a=s.nextInt();
		String str=Integer.toBinaryString(a);
		System.out.println("Binary value of " +a+" is "+str);
		int x=str.length();
		int c=0;
		for(int i=0;i<x;i++){
			if(str.charAt(i)=='0'){
			c++;
			}
		}
		System.out.println("number of zeroes= "+c);
		
				
}}