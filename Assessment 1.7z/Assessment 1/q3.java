import java.util.*;//Importing the required java packages
class q3{//class name
	public static void main(String args[]){
		boolean[][] a = {{true, false, true},
						 {false, true, false}};//bool array
		int r=a.length;//row length
		int c=a[0].length;//column length
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				//checking for boolean values 
				if (a[i][j]) {
					System.out.print("t ");
				} else {
					System.out.print("f ");
				}
				
			}
			System.out.println();
		}
	}
}

