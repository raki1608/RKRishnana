import java.util.*;//Importing the required java packages
class q2{//class name
	public static void main(String args[]){
		double a,b;//decalring double variables
		Scanner s=new Scanner(System.in);//for user input
		System.out.println("Input 1st number");
		a=s.nextDouble();
		System.out.println("Input 2nd number");
		b=s.nextDouble();
		//checking for conditions
		if ((a<1 && a>0) && (b<1 && b>0))
			System.out.println("True");
		else
			System.out.println("False");
		
		}
}
			
			