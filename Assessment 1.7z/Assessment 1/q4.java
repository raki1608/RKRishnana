import java.util.*;//Importing the required java packages
class q4{//class name
	public static void main(String args[]){
		int [][] a={{10,20,30},
					{40,50,60}};
		System.out.println("Original array is");
		int r=a.length;//row length
		int c=a[0].length;//column length
		//printing org array
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("After changing the array is:");
		//looping in different way without changing the contents
		for (int i = 0; i < c; i++) {
			for (int j = 0; j < r; j++) {
					System.out.print(a[j][i]+" ");
			}
			System.out.println();
		}
	}
}
				