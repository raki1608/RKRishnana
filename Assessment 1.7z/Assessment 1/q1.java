import java.util.*;//Importing the required java packages
class q1{//class name
	public static void main(String args[]){//main method
		int a,b,c,d;//declaring 4 numbers
		Scanner s=new Scanner(System.in);//for user input
		System.out.println("Input 1st number");
		a=s.nextInt();
		System.out.println("Input 2nd number");
		b=s.nextInt();
		System.out.println("Input 3rd number");
		c=s.nextInt();
		System.out.println("Input 4th number");
		d=s.nextInt();
		if(a==b && b==c && c==d)//comparing
			System.out.println("Numbers are equal");
		else
			System.out.println("Numbers are not equal");
		
	}
}
		
	
	