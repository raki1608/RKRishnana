import java.util.*;//Importing the required java packages
class q5{//class name
	public static void main(String args[]){
		int a[]={ 1, 4, 17, 7, 25, 3, 100};
		int k;
		System.out.println("Original Array");
		System.out.println(Arrays.toString(a));
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the k value");
		k=s.nextInt();
		Arrays.sort(a);
		int x=a.length;
		System.out.println("The k largest values are:");
		for(int i=x-1;i>=x-k;i--){
			System.out.println(a[i]);
		}
	}
}
		